package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class AdminPage extends AppCompatActivity {
    Button button;
    UserPage value = new UserPage();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_page);
        button = findViewById(R.id.logout);
        button.setOnClickListener(view -> {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(getApplicationContext(), login.class);
            startActivity(intent);
            finish();

        });
        button = findViewById(R.id.btn_entranceHistory);
        button.setOnClickListener(view -> {
             Intent intent = new Intent(getApplicationContext(),History.class);
            startActivity(intent);
            finish();


        });
        button = findViewById(R.id.btn_allowedPlates);
        button.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(),Plates.class);
            startActivity(intent);
            finish();


        });
        button = findViewById(R.id.btn_requests);
        button.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(),Request.class);
            startActivity(intent);
            finish();


        });
        button = findViewById(R.id.btn_addDeleteResidents);
        button.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(),Residents.class);
            startActivity(intent);
            finish();


        });
    }




}