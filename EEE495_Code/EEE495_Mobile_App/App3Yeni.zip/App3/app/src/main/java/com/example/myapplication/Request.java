package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Request extends AppCompatActivity {
    Button button;
    public static String request = "";
    public static String allowedPlates = "";
    UserPage a = new UserPage();

    // Access the variable x from ClassA

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request);
        request = a.inputToSend;
        setContentView(R.layout.activity_request);
        TextView textView = (TextView) findViewById(R.id.textViewRequest);
        textView.setText(request);
        button = findViewById(R.id.btn_backRequest);
        button.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(),AdminPage.class);
            startActivity(intent);
            finish();


        });



    }
    public String handleText6(View v){
        TextView t = (TextView) findViewById(R.id.textViewRequest);
        String inputToFirebase = t.getText().toString();
        allowedPlates = allowedPlates + inputToFirebase;
        inputToFirebase = inputToFirebase + " is Accepted";
        Log.d("infoFirebase",inputToFirebase );
        return inputToFirebase;
    }
    public String handleText7(View v){
        TextView t = (TextView) findViewById(R.id.textViewRequest);
        String inputToFirebase = t.getText().toString();
        inputToFirebase = inputToFirebase + " is Denied";
        Log.d("infoFirebase",inputToFirebase );
        return inputToFirebase;
    }
    // inputToFirebase: Firebase'e yollanacak input.
}