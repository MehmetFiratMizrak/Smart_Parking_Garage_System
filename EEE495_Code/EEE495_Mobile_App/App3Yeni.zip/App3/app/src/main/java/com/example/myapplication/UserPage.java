package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.util.Log;
import android.view.View;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.auth.FirebaseAuth;


public class UserPage extends AppCompatActivity {
    Button button;
    public static String inputToSend = " ";
    public static String inputToAllowedPlates = " ";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_page);
        button = findViewById(R.id.logout);
        button.setOnClickListener(view -> {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(getApplicationContext(), login.class);
            startActivity(intent);
            finish();

        });
    }
    public String handleText(View v){
        EditText t = findViewById(R.id.plateNo);
        String input = t.getText().toString();
        inputToAllowedPlates = input;
        input = input + " Has a request for Adding";
        inputToSend = input;
        Log.d("info",input );
        return input;
    }
    public String handleText2(View v){
        EditText t = findViewById(R.id.plateNo);
        String input = t.getText().toString();
        input = input + " Has a request for Deleting";
        inputToSend = input;
        Log.d("info",input );
        return input;
    }
    public String handleText3(View v){
        EditText t = findViewById(R.id.plateNo);
        String input = t.getText().toString();
        input = input + " Has a request for Temporarily Adding";
        inputToSend = input;
        Log.d("info",input );
        return input;
    }

}